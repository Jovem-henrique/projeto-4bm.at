import json
import os

if os.path.exists("estoque.json"):
    with open("estoque.json", "r", encoding="utf-8") as f:
        estoque = json.load(f)
else:
    estoque = []

def salvar():
    with open("estoque.json", "w", encoding="utf-8") as f:
        json.dump(estoque, f, indent=2, ensure_ascii=False)


def cadastrar_produto():
    print(" CADASTRAR PRODUTO ")
    if len(estoque) == 0:
        novo_id = 1
    else:
        novo_id = estoque[-1]["id"] + 1
    print(f"ID do novo produto: {novo_id}")
    nome = input("Nome do Produto: ").strip()
    try:
        marca = input("Marca: ")
        quantidade = int(input("Quantidade: "))
        tamanho = input("Tamanho: ").strip().upper()
        cor = input("Qual a cor do produto?: ")
        armazenamento = input("Tem armazenamento? Caso não, digite '0': ")
        preco = float(input("Preço: "))
        valor = float(input("Peso (só o número): "))
        unidade = input("Unidade (kg ou g): ")
        peso = f"{valor}{unidade}" 
        novo_produto = {
        "id": novo_id,
        "nome": nome,
        "marca": marca,
        "quantidade": quantidade,
        "tamanho": tamanho,
        "cor": cor,
        "armazenamento": armazenamento,
        "preco": preco,
        "peso": peso  
    }
        estoque.append(novo_produto)
        salvar()
        print(f"Produto cadastrado com sucesso! ID: '{novo_id}'")
    except ValueError:
        print("ERRO: Digitos números válidos para quantidade, peso e preço")
def pesquisar_produto():
    print(" PESQUISAR POR ID ")
    try:
        id_busca = int(input("Digite o ID para buscar: "))
    except ValueError:
        print("Erro: Digite apenas números.")
        return

    encontrado = False
    for produto in estoque:
        if produto["id"] == id_busca:
            print("-" * 40)
            print(f"ID: {produto['id']} | NOME: {produto['nome']}")
            print(f"MARCA: {produto ['marca']}")
            print(f"QUANTIDADE: {produto['quantidade']}") 
            print(f"TAMANHO: {produto['tamanho']}" )
            print(f"COR: {produto['cor']}" )
            print(f"ARMAZENAMENTO: {produto['armazenamento']}")
            print(f"PREÇO: R$ {produto['preco']:.2f}")
            print(f"PESO: {produto['peso']}")
            print("-" * 40)
            encontrado = True
            break 
    if not encontrado:
        print("Produto com esse ID não encontrado.")

def consultar_produtos():
    print(" RELATÓRIO GERAL ")
    if len(estoque) == 0:
        print("O estoque está vazio no momento.")
        return
    print(f"{'ID':<5} | {'NOME':<20} | {'MARCA':<5} | {'TAMANHO':<8} | {'COR':<10} | {'ARMAZENAMENTO':<5} | {'QUANTIDADE':<5} | {'PREÇO':<10} | {'PESO'}")
    print("-" * 120)
    
    for produto in estoque:
        i_id = produto["id"]
        nome = produto["nome"]
        marca = produto["marca"]
        quantidade = produto["quantidade"]
        tamanho = produto ["tamanho"]
        cor = produto ["cor"]
        armazenamento = produto ["armazenamento"]
        preco = produto["preco"]
        peso = produto["peso"]
        nome_na_tabela = nome[:20]
        print(f"{i_id:<5} | {nome_na_tabela:<20} | {marca:<5} | {tamanho:<7} | {cor:<7} | {armazenamento:<11} | {quantidade:<10} | R$ {preco:<7.2f} | {peso}")
    print("-" * 120)

def atualizar_produto():
    print(" ATUALIZAR")
    consultar_produtos() 
    try:
        id_busca = int(input("Qual o ID do produto deseja atualizar?: "))
    except ValueError:
        print("Use apenas números.")
        return
    
    for produto in estoque:
        if produto["id"] == id_busca:
            print(f"Produto encontrado: {produto['nome']}")
            print("O que deseja mudar?")
            print("1 - Nome")
            print("2 - Marca")
            print("3 - Quantidade")
            print("4 - Tamanho")
            print("5 - Cor")
            print("6 - Armazenamento")
            print("7 - Preço")
            print("8 - Peso")
            print("9 - Tudo")
            opcao = input("Opção: ")
            if opcao == "1":
                novo_nome = input("Novo Nome: ")
                produto["nome"] = novo_nome
            elif opcao == "2":
                nova_marca = int(input("Nova marca: "))
                produto["marca"] = nova_marca
            elif opcao == "3":
                nova_quantidade = int(input("Nova Quantidade: "))
                produto["quantidade"] = nova_quantidade
            elif opcao == "4":
                novo_tamanho = (input("Novo Tamanho: "))
                produto["tamanho"] = novo_tamanho
            elif opcao == "5":
                nova_cor = (input("Nova cor: "))
                produto["cor"] = nova_cor
            elif opcao == "6":
                novo_armazenamento = (input("Novo armazenamento: "))
                produto["armazenamento"] = novo_armazenamento
            elif opcao == "7":
                novo_preco = float(input("Novo Preço: "))
                produto["preco"] = novo_preco
            elif opcao == "8":
                valor = input("Novo Peso (só o número): ")
                unidade = input("Unidade (kg ou g): ")
                produto["peso"] = f"{valor}{unidade}"
            elif opcao == "9":
                novo_nome = input("Novo Nome: ")
                produto["nome"] = novo_nome
                nova_marca = int(input("Nova marca: "))
                produto["marca"] = nova_marca
                nova_quantidade = int(input("Nova Quantidade: "))
                produto["quantidade"] = nova_quantidade
                novo_tamanho = (input("Novo Tamanho: "))
                produto["tamanho"] = novo_tamanho
                nova_cor = (input("Nova cor: "))
                produto["cor"] = nova_cor
                novo_armazenamento = (input("Novo armazenamento: "))
                produto["armazenamento"] = novo_armazenamento
                novo_preco = float(input("Novo Preço: "))
                produto["preco"] = novo_preco
                valor = input("Novo Peso (só o número): ")
                unidade = input("Unidade (kg ou g): ")
                produto["peso"] = f"{valor}{unidade}"
            else:
                print("Opção inválida.")
                return
            
            salvar() 
            print("Atualizado com sucesso!")
            return 
            
    print("ID não encontrado na lista.")

def deletar_produto():
    print(" DELETAR PRODUTO")
    consultar_produtos()
    try:
        id_busca = int(input("Qual ID deseja deletar?: "))
    except ValueError:
        print("Use apenas números.")
        return

    for produto in estoque:
        if produto["id"] == id_busca:
            print(f"Deletando: {produto['nome']}")
            confirmacao = input("Tem certeza? (s/n): ")
            
            if confirmacao.lower() == "s":
                estoque.remove(produto)
                salvar()
                print("Produto completamente removido.")
            else:
                print("Cancelado.")
            return

    print("ID não encontrado.")

while True:
    print(" CONTROLE DE ESTOQUE ")
    print("1. Cadastrar Produto")
    print("2. Pesquisar Produto")
    print("3. Consultar Produtos") 
    print("4. Atualizar Produto")
    print("5. Deletar Produto")
    print("6. Sair")
    
    opcao = input("Escolha: ")

    if opcao == "1": cadastrar_produto()
    elif opcao == "2": pesquisar_produto()
    elif opcao == "3": consultar_produtos()
    elif opcao == "4": atualizar_produto()
    elif opcao == "5": deletar_produto()
    elif opcao == "6": break